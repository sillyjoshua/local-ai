const MODE_META = {
  chat: { title: 'Chat', desc: 'General-purpose conversation', role: 'chat', empty: 'Ask anything. Powered by llama2.' },
  uncensored: { title: 'Uncensored Chat', desc: 'Unrestricted, direct answers', role: 'uncensored', empty: 'Direct, unfiltered conversation. Powered by llama2-uncensored.' },
  code: { title: 'Code Assistant', desc: 'Coding help & review', role: 'code', empty: 'Paste code or describe what to build. Powered by qwen2.5-coder:7b.' },
  image: { title: 'Image Prompts', desc: 'Generate detailed image-gen prompts', role: 'image', empty: 'Describe an image idea and get a ready-to-use prompt.' },
};

let state = {
  mode: 'chat',
  sessions: {},      // id -> { mode, title, messages: [{role, content}] }
  currentSessionId: null,
  modelStatus: null,
};

function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }

function newSession(mode) {
  const id = uid();
  state.sessions[id] = { id, mode, title: 'New chat', messages: [] };
  state.currentSessionId = id;
  return id;
}

function currentSession() {
  return state.sessions[state.currentSessionId];
}

function renderSidebarModes() {
  document.querySelectorAll('.mode-btn').forEach(btn => {
    const mode = btn.dataset.mode;
    btn.classList.toggle('active', mode === state.mode);
    const available = state.modelStatus && state.modelStatus.available && state.modelStatus.available[MODE_META[mode].role];
    btn.classList.toggle('unavailable', state.modelStatus && state.modelStatus.ollamaRunning && !available);
  });
}

function renderSessionList() {
  const list = document.getElementById('session-list');
  list.innerHTML = '';
  Object.values(state.sessions)
    .filter(s => s.mode === state.mode)
    .sort((a, b) => b.id.localeCompare(a.id))
    .forEach(s => {
      const el = document.createElement('div');
      el.className = 'session-item' + (s.id === state.currentSessionId ? ' active' : '');
      el.textContent = s.title;
      el.onclick = () => { state.currentSessionId = s.id; renderAll(); };
      list.appendChild(el);
    });
}

function renderTopbar() {
  const meta = MODE_META[state.mode];
  document.getElementById('mode-title').textContent = meta.title;
  document.getElementById('mode-desc').textContent = meta.desc;
  const role = meta.role;
  const model = state.modelStatus && state.modelStatus.available ? state.modelStatus.available[role] : null;
  document.getElementById('model-badge').textContent = model || 'no model';
}

function escapeHtml(str) {
  return str.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function formatContent(content) {
  // Basic markdown code block + inline code rendering
  let html = escapeHtml(content);
  html = html.replace(/```(\w*)\n([\s\S]*?)```/g, (m, lang, code) => `<pre><code>${code}</code></pre>`);
  html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
  html = html.replace(/\n/g, '<br>');
  return html;
}

function renderChatWindow() {
  const win = document.getElementById('chat-window');
  const session = currentSession();
  win.innerHTML = '';
  if (!session || session.messages.length === 0) {
    win.innerHTML = `<div id="empty-state"><div class="big">${MODE_META[state.mode].title}</div><div class="small">${MODE_META[state.mode].empty}</div></div>`;
    return;
  }
  session.messages.forEach(m => {
    const div = document.createElement('div');
    div.className = 'msg ' + (m.role === 'user' ? 'user' : 'assistant');
    div.innerHTML = `<div class="msg-role">${m.role === 'user' ? 'You' : 'Assistant'}</div><div class="msg-bubble">${formatContent(m.content)}</div>`;
    win.appendChild(div);
  });
  win.scrollTop = win.scrollHeight;
}

function renderAll() {
  renderSidebarModes();
  renderSessionList();
  renderTopbar();
  renderChatWindow();
}

function showBanner(text) {
  const b = document.getElementById('banner');
  if (!text) { b.style.display = 'none'; return; }
  b.textContent = text;
  b.style.display = 'block';
}

async function refreshStatus() {
  try {
    const res = await fetch('/api/status');
    const data = await res.json();
    state.modelStatus = data;
    const dot = document.getElementById('ollama-dot');
    const text = document.getElementById('ollama-status-text');
    const modelsLine = document.getElementById('models-line');
    if (data.ollamaRunning) {
      dot.className = 'status-dot status-ok';
      text.textContent = 'ollama connected';
      const roles = ['chat', 'uncensored', 'code'];
      modelsLine.innerHTML = roles.map(r => {
        const m = data.available[r];
        return `${m ? '✓' : '✗'} ${r}`;
      }).join('&nbsp;&nbsp;');
      const anyModel = Object.values(data.available).some(Boolean);
      showBanner(anyModel ? '' : 'No supported models found. Run: ollama pull llama2');
    } else {
      dot.className = 'status-dot status-bad';
      text.textContent = 'ollama not running';
      modelsLine.textContent = '';
      showBanner('Cannot reach Ollama. Start it with: ollama serve');
    }
  } catch (e) {
    showBanner('Cannot reach the local server.');
  }
  renderAll();
}

async function sendMessage() {
  const input = document.getElementById('input-box');
  const text = input.value.trim();
  if (!text) return;

  let session = currentSession();
  if (!session || session.mode !== state.mode) {
    const id = newSession(state.mode);
    session = state.sessions[id];
  }

  session.messages.push({ role: 'user', content: text });
  if (session.title === 'New chat') session.title = text.slice(0, 32);
  input.value = '';
  input.style.height = 'auto';
  renderAll();

  const sendBtn = document.getElementById('send-btn');
  sendBtn.disabled = true;

  session.messages.push({ role: 'assistant', content: '' });
  renderAll();

  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mode: state.mode, messages: session.messages.slice(0, -1) }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Unknown error' }));
      session.messages[session.messages.length - 1].content = `[error] ${err.error}`;
      renderAll();
      sendBtn.disabled = false;
      return;
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n\n');
      buffer = lines.pop();
      for (const line of lines) {
        if (!line.startsWith('data: ')) continue;
        const payload = JSON.parse(line.slice(6));
        if (payload.error) {
          session.messages[session.messages.length - 1].content += `\n[error] ${payload.error}`;
        } else if (payload.token) {
          session.messages[session.messages.length - 1].content += payload.token;
        }
        renderChatWindow();
      }
    }
  } catch (e) {
    session.messages[session.messages.length - 1].content = `[error] ${e.message}`;
  }

  sendBtn.disabled = false;
  renderAll();
}

document.querySelectorAll('.mode-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    if (btn.classList.contains('unavailable')) return;
    state.mode = btn.dataset.mode;
    const existing = Object.values(state.sessions).find(s => s.mode === state.mode);
    state.currentSessionId = existing ? existing.id : newSession(state.mode);
    renderAll();
  });
});

document.getElementById('new-chat-btn').addEventListener('click', () => {
  newSession(state.mode);
  renderAll();
});

document.getElementById('send-btn').addEventListener('click', sendMessage);
document.getElementById('input-box').addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});
document.getElementById('input-box').addEventListener('input', function () {
  this.style.height = 'auto';
  this.style.height = Math.min(this.scrollHeight, 160) + 'px';
});

newSession('chat');
refreshStatus();
setInterval(refreshStatus, 10000);
renderAll();
