// Preload script runs in a privileged context before the renderer loads.
// Currently the app doesn't need to expose any Node/Electron APIs to the
// page (all communication happens over plain HTTP to the local server),
// so this file intentionally does nothing but exists for the standard
// Electron process model: main.js -> preload.js -> renderer/.
