const { app, BrowserWindow, Menu, shell } = require('electron');
const path = require('path');

let mainWindow;
let serverStarted = false;
const PORT = process.env.PORT || 3000;

function startServer() {
  if (serverStarted) return;
  serverStarted = true;
  process.env.PORT = String(PORT);
  require('./server.js');
}

function loadWindow() {
  mainWindow.loadURL(`http://localhost:${PORT}`).catch(() => {
    setTimeout(loadWindow, 300);
  });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    minWidth: 820,
    minHeight: 560,
    backgroundColor: '#0d0f0e',
    title: 'Local AI',
    autoHideMenuBar: true,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      preload: path.join(__dirname, 'preload.js'),
    },
  });

  loadWindow();

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(() => {
  Menu.setApplicationMenu(null);
  startServer();
  setTimeout(createWindow, 500);

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
