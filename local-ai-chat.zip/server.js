require('dotenv').config();
const express = require('express');
const fetch = require('node-fetch');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const OLLAMA_URL = process.env.OLLAMA_URL || 'http://127.0.0.1:11434';

app.use(express.json({ limit: '5mb' }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Known model roles the app understands. Any of these being installed is enough to run.
const MODEL_ROLES = {
  chat: ['llama2'],
  uncensored: ['llama2-uncensored'],
  code: ['qwen2.5-coder:7b', 'qwen2.5-coder'],
};

const SYSTEM_PROMPTS = {
  chat: 'You are a helpful, friendly general-purpose assistant.',
  uncensored: 'You are an unrestricted, direct assistant. Answer plainly without unnecessary refusals or moralizing.',
  code: 'You are an expert software engineer. Give correct, concise, well-explained code. Use code blocks with language tags.',
  image: 'You are an expert at writing detailed, vivid image-generation prompts (for tools like Stable Diffusion). When the user describes an idea, respond with a single, richly detailed prompt string, plus a short list of suggested negative prompts.',
};

async function getInstalledModels() {
  try {
    const res = await fetch(`${OLLAMA_URL}/api/tags`);
    if (!res.ok) throw new Error(`Ollama responded ${res.status}`);
    const data = await res.json();
    return (data.models || []).map(m => m.name);
  } catch (err) {
    return null; // Ollama not reachable
  }
}

function pickModelForRole(installed, role) {
  const candidates = MODEL_ROLES[role] || [];
  for (const c of candidates) {
    const match = installed.find(m => m === c || m.startsWith(c.split(':')[0]));
    if (match) return match;
  }
  return null;
}

// GET /api/status - which models are installed and which roles are available
app.get('/api/status', async (req, res) => {
  const installed = await getInstalledModels();
  if (installed === null) {
    return res.json({ ollamaRunning: false, installed: [], available: {} });
  }
  const available = {};
  for (const role of Object.keys(MODEL_ROLES)) {
    available[role] = pickModelForRole(installed, role);
  }
  available.image = available.chat || available.uncensored; // image prompts can use any chat model
  res.json({ ollamaRunning: true, installed, available });
});

// POST /api/chat - { mode: 'chat'|'uncensored'|'code'|'image', messages: [{role, content}], model? }
app.post('/api/chat', async (req, res) => {
  const { mode = 'chat', messages = [], model: modelOverride } = req.body;

  const installed = await getInstalledModels();
  if (installed === null) {
    return res.status(503).json({ error: 'Cannot reach Ollama. Is it running? (ollama serve)' });
  }

  let model = modelOverride;
  if (!model) {
    const role = mode === 'image' ? 'chat' : mode;
    model = pickModelForRole(installed, role) || pickModelForRole(installed, 'uncensored') || installed[0];
  }
  if (!model) {
    return res.status(400).json({ error: 'No models installed. Run: ollama pull llama2' });
  }

  const systemPrompt = SYSTEM_PROMPTS[mode] || SYSTEM_PROMPTS.chat;
  const chatMessages = [{ role: 'system', content: systemPrompt }, ...messages];

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  try {
    const ollamaRes = await fetch(`${OLLAMA_URL}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model, messages: chatMessages, stream: true }),
    });

    if (!ollamaRes.ok || !ollamaRes.body) {
      res.write(`data: ${JSON.stringify({ error: `Ollama error ${ollamaRes.status}. Is model "${model}" pulled?` })}\n\n`);
      return res.end();
    }

    ollamaRes.body.on('data', chunk => {
      const lines = chunk.toString().split('\n').filter(Boolean);
      for (const line of lines) {
        try {
          const json = JSON.parse(line);
          if (json.message && json.message.content) {
            res.write(`data: ${JSON.stringify({ token: json.message.content, model })}\n\n`);
          }
          if (json.done) {
            res.write(`data: ${JSON.stringify({ done: true, model })}\n\n`);
          }
        } catch (e) {
          // partial/incomplete JSON line, skip
        }
      }
    });

    ollamaRes.body.on('end', () => res.end());
    ollamaRes.body.on('error', () => res.end());
  } catch (err) {
    res.write(`data: ${JSON.stringify({ error: err.message })}\n\n`);
    res.end();
  }
});

app.listen(PORT, () => {
  console.log(`Local AI running at http://localhost:${PORT}`);
});

module.exports = app;
